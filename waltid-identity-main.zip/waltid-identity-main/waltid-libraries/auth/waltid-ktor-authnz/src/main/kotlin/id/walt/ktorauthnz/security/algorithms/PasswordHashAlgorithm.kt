package id.walt.ktorauthnz.security.algorithms

//import kotlinx.io.bytestring.ByteString

abstract class PasswordHashAlgorithm {

    //abstract suspend fun hash(password: String, salt: ByteString): String

}
