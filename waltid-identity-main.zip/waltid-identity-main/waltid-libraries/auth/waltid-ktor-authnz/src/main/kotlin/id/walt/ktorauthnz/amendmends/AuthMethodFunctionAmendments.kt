package id.walt.ktorauthnz.amendmends

enum class AuthMethodFunctionAmendments {
    Registration
}
