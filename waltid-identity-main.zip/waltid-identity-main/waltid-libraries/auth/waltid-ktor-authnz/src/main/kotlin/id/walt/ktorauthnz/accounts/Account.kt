package id.walt.ktorauthnz.accounts

data class Account(
    val id: String,
    val name: String? = null,
)
