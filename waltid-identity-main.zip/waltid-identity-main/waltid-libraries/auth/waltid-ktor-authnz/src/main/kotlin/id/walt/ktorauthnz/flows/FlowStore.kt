package id.walt.ktorauthnz.flows

/**
 * Store for Flow stored data (account unspecific data)
 */
object FlowStore
