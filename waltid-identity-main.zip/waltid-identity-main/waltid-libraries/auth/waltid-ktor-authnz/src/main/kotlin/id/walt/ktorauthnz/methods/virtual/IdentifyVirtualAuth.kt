package id.walt.ktorauthnz.methods.virtual

abstract class IdentifyVirtualAuth(id: String) : VirtualAuthMethod(id)
