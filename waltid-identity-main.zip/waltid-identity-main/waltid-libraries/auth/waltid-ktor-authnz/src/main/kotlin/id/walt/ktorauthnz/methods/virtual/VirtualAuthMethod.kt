package id.walt.ktorauthnz.methods.virtual

import id.walt.ktorauthnz.methods.AuthenticationMethod

abstract class VirtualAuthMethod(id: String) : AuthenticationMethod(id)
