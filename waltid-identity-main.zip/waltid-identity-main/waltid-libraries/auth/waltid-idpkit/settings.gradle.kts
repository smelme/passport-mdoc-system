rootProject.name = "waltid-idpkit"
