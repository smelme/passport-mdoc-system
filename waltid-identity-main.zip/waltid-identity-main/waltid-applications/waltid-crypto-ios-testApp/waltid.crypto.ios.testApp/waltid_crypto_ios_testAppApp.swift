//
//  waltid_crypto_ios_testAppApp.swift
//  waltid.crypto.ios.testApp
//
//  Created by Ivan Pagac on 18/06/2024.
//

import SwiftUI

@main
struct waltid_crypto_ios_testAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
