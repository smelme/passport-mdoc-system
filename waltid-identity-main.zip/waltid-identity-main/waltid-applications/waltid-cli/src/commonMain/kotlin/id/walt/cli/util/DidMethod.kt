package id.walt.cli.util

enum class DidMethod {
    KEY,
    JWK,
    WEB,
    CHEQD,
    IOTA
}