package id.walt.cli.util

import com.github.ajalt.clikt.output.Localization

object WaltIdCmdHelpOptionMessage: Localization {
    override fun helpOptionMessage() = "Show this message and exit."
}