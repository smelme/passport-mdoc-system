package id.walt.androidSample.models

data class CopiedText(val text: String, val label: String)