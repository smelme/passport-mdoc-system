<template>
  <DidCreationView method="jwk" />
</template>

<script lang="ts" setup>
import DidCreationView from "@waltid-web-wallet/components/dids/DidCreationView.vue";
</script>
