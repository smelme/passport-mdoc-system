<template>
  <CenterMain>
    <h1 class="font-semibold">Settings main</h1>

    <p>
      Additional settings can be added here, as to not clutter the sidebar menus
      or profile menus.
    </p>
  </CenterMain>
</template>

<script setup>
import CenterMain from "@waltid-web-wallet/components/CenterMain.vue";
</script>

<style scoped></style>
