<template>
    <CenterMain>
        <h1 class="font-normal">Settings</h1>
        <p>This is <b>rendered from markdown.</b></p>
    </CenterMain>
</template>

<script>
definePageMeta({
    layout: "default-reduced-nav",
})
</script>