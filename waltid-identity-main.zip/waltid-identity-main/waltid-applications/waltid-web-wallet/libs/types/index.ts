export interface ILink {
    id: number;
    title: string;
    url: any;
    icon: string;
}
