//import { BeaconWallet } from "@taquito/beacon-wallet";

/*
const useTezosWallet = () => {
    const account = ref('')
    const wallet = new BeaconWallet({ name: "Walt.id" });

    async function connect() {
        const permissions = await wallet.client.requestPermissions();
        account.value = permissions.address;
    }

    return {
        account,
        connect,
    }
}

export default useTezosWallet;*/
