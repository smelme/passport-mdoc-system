<template>
    <main class="mx-auto w-full px-4 sm:px-6 lg:mx-auto lg:max-w-6xl lg:px-8 p-3 lg:p-0 mt-3">
        <slot />
    </main>
</template>

<script setup></script>

<style scoped></style>
