//
//  iosAppApp.swift
//  iosApp
//
//  Created by Ivan Pagac on 26/06/2024.
//

import SwiftUI

@main
struct iosAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
